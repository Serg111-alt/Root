var date_in_future = new Date(2019,0,01);
// Установить дату и время в будущем
var date_in_future = new Date(2020, 0, 1, 10, 32, 4); // 1.01.2019, 10:32:04          
var x;
function timer() {

  // Установить дату и время текущего момента
  var date = new Date().getTime();

  // Разница в милисекундах между текущей и будущей датой 
  var ms = date_in_future - date;

  // Подсчет разницы времени в днях, часах, минутах и секундах
  var days = Math.floor(ms / (1000 * 60 * 60 * 24));
  var hours = Math.floor((ms % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((ms % (1000 * 60)) / 1000);

  // Показать результат в теге с id="time"
  document.getElementById("time").innerHTML = "Осталось до курса 1.01.2019, 10:32:04 - " + days + "дней " + hours + "часов "
  + minutes + "минут " + seconds + "секунд ";

  // Если время истекло, показать сообщение
  if (ms < 0) {
  clearInterval(x);
  document.getElementById("time").innerHTML = "Время истекло!";
  }
  x = setInterval(timer, 1000);
}
$(document).ready(function() {
    var offset = 200; // координата сдвига по оси Y
    var duration = 300; //время выполнения
    $('#totop').fadeOut(0); 
    
    
      /* Добавить плавный скроллинг ко всем ссылкам внутри тега navbar*/
      $("a[href^='#']").on("click", function(event) {
        //this.hash - атрибут 'href' ссылки
        var hash = $(this).attr("href"); //сохраняем атрибут href
        if (hash !== "") { //проверяем, не пустое ли поле 'href'      
          // Используем метод jQuery animate(), чтобы добавить плавный скроллинг
          $("html, body").animate(
            {scrollTop: $(hash).offset().top // устанавливаем новое положение документа по якорю
            }, 900  //900-число миллисекунд - время анимации        
          );
        }
      });
    
     $(window).scroll(function() { // если происходит скроллинг
        $(".slideanim").each(function(){ // для каждого блока с классом slideanim
          var pos = $(this).offset().top; // считываем его координату по оси Y в окне браузера
      
          var winTop = $(window).scrollTop(); // сохраняем текущую верхнюю координату окна браузера (верх страницы)
      
          if (pos < winTop + 400) { //если до верха страницы остается 400px, 
            $(this).addClass("slide"); //добавляем к блоку класс slide с анимацией
          }
        });
    
        if ($(window).scrollTop() > offset) {
          $("#totop").css("opacity", "0.8"); // возвращаем прозрачность
          $("#totop").fadeIn(duration); // функция плавно исчезает
        } else {
          $("#totop").fadeOut(duration); // функция плавно появляется
        }
    if ($(this).scrollTop() > offset) {
          $('#eye').removeClass('logo');
          $('#eye').addClass('logosmall');
        }
        else{
          $('#eye').removeClass('logosmall');
          $('#eye').addClass('logo');
      }
    
    var winTop = $(window).scrollTop();
    $('.jumbotron').css('background-position','center ' + -(winTop*.5)+'px');
    
    $('.mov_slideInRight').each(function(){// для каждого блока с классом mov_slideInRight
    var pos = $(this).offset().top;// считываем его координату по оси Y в окне браузера
    if (pos < winTop + 600) { //если до верха страницы остается 600px,
    $(this).addClass('slideInRight'); //добавляем к блоку класс с анимацией slideInRight
    }
    });
    
    $('.mov_slideInLeft').each(function(){// для каждого блока с классом mov_slideInRight
    var pos = $(this).offset().top;// считываем его координату по оси Y в окне браузера
    if (pos < winTop + 600) { //если до верха страницы остается 600px,
    $(this).addClass('slideInLeft'); //добавляем к блоку класс с анимацией slideInRight
    }
    });
    
      });
    
    });
    

    